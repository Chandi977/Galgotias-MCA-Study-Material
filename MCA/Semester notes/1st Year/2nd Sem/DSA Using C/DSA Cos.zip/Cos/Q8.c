#include <stdio.h>
#include <stdlib.h>

// Structure for a node in the queue
struct Node {
    int data;
    struct Node* next;
};

// Structure for the queue
struct Queue {
    struct Node* front; // Front of the queue
    struct Node* rear; // Rear of the queue
};

// Function to create a new node
struct Node* newNode(int data) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    return temp;
}

// Function to create an empty queue
struct Queue* createQueue() {
    struct Queue* q = (struct Queue*)malloc(sizeof(struct Queue));
    q->front = NULL;
    q->rear = NULL;
    return q;
}

// Function to check if the queue is empty
int isEmpty(struct Queue* q) {
    return (q->front == NULL);
}

// Function to enqueue an element into the queue
void enqueue(struct Queue* q, int data) {
    struct Node* temp = newNode(data);
    if (isEmpty(q)) {
        q->front = temp;
    } else {
        q->rear->next = temp;
    }
    q->rear = temp;
    printf("%d enqueued to the queue\n", data);
}

// Function to dequeue an element from the queue
int dequeue(struct Queue* q) {
    int data;
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return -1;
    }
    struct Node* temp = q->front;
    q->front = q->front->next;
    if (q->front == NULL) // If front becomes NULL, set rear to NULL as well
        q->rear = NULL;
    data = temp->data;
    free(temp);
    return data;
}

// Function to display the queue
void display(struct Queue* q) {
    struct Node* temp = q->front;
    if (isEmpty(q)) {
        printf("Queue is empty\n");
        return;
    }
    printf("Elements in Queue are: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    struct Queue* q = createQueue();

    // Enqueue elements
    enqueue(q, 1);
    enqueue(q, 2);
    enqueue(q, 3);
    enqueue(q, 4);
    enqueue(q, 5);

    // Display elements
    display(q);

    // Dequeue elements
    printf("Dequeued element: %d\n", dequeue(q));
    printf("Dequeued element: %d\n", dequeue(q));

    // Display elements
    display(q);

    // Enqueue elements
    enqueue(q, 6);
    enqueue(q, 7);

    // Display elements
    display(q);

    free(q); // free allocated memory for queue
    return 0;
}