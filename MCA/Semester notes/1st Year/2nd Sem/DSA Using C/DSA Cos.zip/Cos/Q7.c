#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 5 // Maximum size of the circular queue

// Structure for the circular queue
struct CircularQueue {
    int* array; // Array to store elements
    int front; // Front of the queue
    int rear; // Rear of the queue
    int size; // Current size of the queue
};

// Function to create a circular queue
struct CircularQueue* createCircularQueue() {
    struct CircularQueue* cq = (struct CircularQueue*)malloc(sizeof(struct CircularQueue));
    cq->array = (int*)malloc(MAX_SIZE * sizeof(int));
    cq->front = -1;
    cq->rear = -1;
    cq->size = 0;
    return cq;
}

// Function to check if the circular queue is full
int isFull(struct CircularQueue* cq) {
    return (cq->front == (cq->rear + 1) % MAX_SIZE && cq->size == MAX_SIZE);
}

// Function to check if the circular queue is empty
int isEmpty(struct CircularQueue* cq) {
    return (cq->front == -1 && cq->rear == -1 && cq->size == 0);
}

// Function to enqueue an element into the circular queue
void enqueue(struct CircularQueue* cq, int data) {
    if (isFull(cq)) {
        printf("Queue is full\n");
        return;
    } else {
        cq->rear = (cq->rear + 1) % MAX_SIZE;
        cq->array[cq->rear] = data;
        if (cq->front == -1)
            cq->front = cq->rear;
        cq->size++;
        printf("%d enqueued to the queue\n", data);
    }
}

// Function to dequeue an element from the circular queue
int dequeue(struct CircularQueue* cq) {
    int data;
    if (isEmpty(cq)) {
        printf("Queue is empty\n");
        return -1;
    } else {
        data = cq->array[cq->front];
        if (cq->front == cq->rear) {
            cq->front = -1;
            cq->rear = -1;
        } else {
            cq->front = (cq->front + 1) % MAX_SIZE;
        }
        cq->size--;
        return data;
    }
}

// Function to display the circular queue
void display(struct CircularQueue* cq) {
    int i;
    if (isEmpty(cq)) {
        printf("Queue is empty\n");
        return;
    }
    printf("Elements in Circular Queue are: ");
    for (i = cq->front; i != cq->rear; i = (i + 1) % MAX_SIZE)
        printf("%d ", cq->array[i]);
    printf("%d\n", cq->array[i]);
}

int main() {
    struct CircularQueue* cq = createCircularQueue();

    // Enqueue elements
    enqueue(cq, 1);
    enqueue(cq, 2);
    enqueue(cq, 3);
    enqueue(cq, 4);
    enqueue(cq, 5);

    // Display elements
    display(cq);

    // Dequeue elements
    printf("Dequeued element: %d\n", dequeue(cq));
    printf("Dequeued element: %d\n", dequeue(cq));

    // Display elements
    display(cq);

    // Enqueue elements
    enqueue(cq, 6);
    enqueue(cq, 7);

    // Display elements
    display(cq);

    free(cq->array); // free allocated memory for array
    free(cq); // free allocated memory for circular queue
    return 0;
}