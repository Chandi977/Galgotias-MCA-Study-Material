 #include <stdio.h>
  #include <conio.h>
  #define N 50

  int main(){
  int m, n, i, j, matrix[N][N], transpose[N][N];

  printf("Enter rows and columns : ");
  scanf("%d%d", &m, &n);

  printf("Enter elements of the matrix : \n");
  for (i= 0; i < m; i++)
    for (j = 0; j < n; j++)
      scanf("%d", &matrix[i][j]);

  for (i = 0;i < m;i++)
    for (j = 0; j < n; j++)
      transpose[j][i] = matrix[i][j];

  printf("Transpose of the matrix:\n");
  for (i = 0; i< n; i++) {
    for (j = 0; j < m; j++)
      printf("%d ", transpose[i][j]);
    printf("\n");
  }
  return 0;
}