#include <stdio.h>
#include <stdlib.h>

// Define a structure for each node in the linked list
struct Node {
  int data;
  struct Node* next;
};

// Define a structure for the stack
struct Stack {
  struct Node* top;
};

// Function to create a new node
struct Node* createNode(int data) {
  struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
  newNode->data = data;
  newNode->next = NULL;
  return newNode;
}

// Function to initialize a stack
struct Stack* initializeStack() {
  struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
  stack->top = NULL;
  return stack;
}

// Function to check if the stack is empty
int isEmpty(struct Stack* stack) {
  return (stack->top == NULL);
}

// Function to push an element onto the stack
void push(struct Stack* stack, int data) {
  struct Node* newNode = createNode(data);
  newNode->next = stack->top;
  stack->top = newNode;
  printf("%d pushed to stack.\n", data);
}

// Function to pop an element from the stack
int pop(struct Stack* stack) {
  if (isEmpty(stack)) {
    printf("Stack underflow.\n");
    return -1;
  }
  struct Node* temp = stack->top;
  int popped = temp->data;
  stack->top = stack->top->next;
  free(temp);
  return popped;
}

// Function to peek at the top element of the stack
int peek(struct Stack* stack) {
  if (isEmpty(stack)) {
    printf("Stack is empty.\n");
    return -1;
  }
  return stack->top->data;
}

// Main function to test the stack implementation
int main() {
  struct Stack* stack = initializeStack();

  push(stack, 10);
  push(stack, 20);
  push(stack, 30);

  printf("Top element is %d.\n", peek(stack));

  printf("%d popped from stack.\n", pop(stack));
  printf("%d popped from stack.\n", pop(stack));

  printf("Top element is %d.\n", peek(stack));

  push(stack, 40);

  printf("Top element is %d.\n", peek(stack));

  return 0;
}